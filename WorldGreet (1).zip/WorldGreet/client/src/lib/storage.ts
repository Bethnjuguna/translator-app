import type { RecentTranslation, FavoriteTranslation } from "@shared/schema";

const RECENT_TRANSLATIONS_KEY = 'recentTranslations';
const FAVORITE_TRANSLATIONS_KEY = 'favoriteTranslations';
const MAX_RECENT_TRANSLATIONS = 5;

export function getRecentTranslations(): RecentTranslation[] {
  try {
    const stored = localStorage.getItem(RECENT_TRANSLATIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function addRecentTranslation(translation: Omit<RecentTranslation, 'id' | 'timestamp'>): void {
  const recent = getRecentTranslations();
  const newTranslation: RecentTranslation = {
    ...translation,
    id: crypto.randomUUID(),
    timestamp: Date.now()
  };

  // Remove duplicate if exists
  const filtered = recent.filter(t => 
    !(t.word === translation.word && 
      t.fromLanguage === translation.fromLanguage && 
      t.toLanguage === translation.toLanguage)
  );

  // Add new translation at the beginning
  const updated = [newTranslation, ...filtered].slice(0, MAX_RECENT_TRANSLATIONS);
  
  localStorage.setItem(RECENT_TRANSLATIONS_KEY, JSON.stringify(updated));
}

export function getFavoriteTranslations(): FavoriteTranslation[] {
  try {
    const stored = localStorage.getItem(FAVORITE_TRANSLATIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function addFavoriteTranslation(translation: Omit<FavoriteTranslation, 'id' | 'timestamp'>): void {
  const favorites = getFavoriteTranslations();
  
  // Check if already exists
  const exists = favorites.some(f => 
    f.word === translation.word && 
    f.fromLanguage === translation.fromLanguage && 
    f.toLanguage === translation.toLanguage
  );

  if (!exists) {
    const newFavorite: FavoriteTranslation = {
      ...translation,
      id: crypto.randomUUID(),
      timestamp: Date.now()
    };

    const updated = [newFavorite, ...favorites];
    localStorage.setItem(FAVORITE_TRANSLATIONS_KEY, JSON.stringify(updated));
  }
}

export function removeFavoriteTranslation(id: string): void {
  const favorites = getFavoriteTranslations();
  const updated = favorites.filter(f => f.id !== id);
  localStorage.setItem(FAVORITE_TRANSLATIONS_KEY, JSON.stringify(updated));
}

export function isFavorite(word: string, fromLanguage: string, toLanguage: string): boolean {
  const favorites = getFavoriteTranslations();
  return favorites.some(f => 
    f.word === word && 
    f.fromLanguage === fromLanguage && 
    f.toLanguage === toLanguage
  );
}
