import type { Language } from "@shared/schema";

// Language code mapping for LibreTranslate API
const languageCodeMap: Record<Language, string> = {
  english: "en",
  spanish: "es", 
  french: "fr",
  portuguese: "pt",
  russian: "ru",
  arabic: "ar",
  mandarin: "zh",
  hindi: "hi",
  japanese: "ja",
  swahili: "sw"
};

export interface ExternalTranslationResult {
  translatedText: string;
  detectedSourceLanguage?: string;
  confidence?: number;
}

export async function translateWithGoogleTranslate(
  text: string, 
  fromLanguage: Language, 
  toLanguage: Language
): Promise<ExternalTranslationResult | null> {
  try {
    const sourceCode = languageCodeMap[fromLanguage];
    const targetCode = languageCodeMap[toLanguage];
    
    if (!sourceCode || !targetCode) {
      throw new Error(`Unsupported language mapping`);
    }

    const response = await fetch("/api/translate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: text,
        source: "auto", // Auto-detect source language
        target: targetCode,
        service: "google"
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Translation API error: ${response.status}`);
    }

    const data = await response.json();
    
    return {
      translatedText: data.translatedText,
      detectedSourceLanguage: data.detectedLanguage,
      confidence: 0.95 // Google Translate typically has high confidence
    };
  } catch (error) {
    console.error("Google Translate failed:", error);
    return null;
  }
}

export async function translateWithLibreTranslate(
  text: string, 
  fromLanguage: Language, 
  toLanguage: Language
): Promise<ExternalTranslationResult | null> {
  try {
    const sourceCode = languageCodeMap[fromLanguage];
    const targetCode = languageCodeMap[toLanguage];
    
    if (!sourceCode || !targetCode) {
      throw new Error(`Unsupported language mapping`);
    }

    const response = await fetch("/api/translate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: text,
        source: "auto", // Auto-detect source language
        target: targetCode,
        service: "libretranslate"
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Translation API error: ${response.status}`);
    }

    const data = await response.json();
    
    return {
      translatedText: data.translatedText,
      detectedSourceLanguage: data.detectedLanguage,
      confidence: 0.8
    };
  } catch (error) {
    console.error("LibreTranslate failed:", error);
    return null;
  }
}

// Smart fallback translation that tries multiple services
export async function translateWithFallback(
  text: string,
  fromLanguage: Language, 
  toLanguage: Language
): Promise<ExternalTranslationResult | null> {
  // Try Google Translate first (best quality for full sentences and cultural context)
  let result = await translateWithGoogleTranslate(text, fromLanguage, toLanguage);
  
  if (result) {
    return result;
  }

  // Fallback to LibreTranslate (free but less reliable)
  result = await translateWithLibreTranslate(text, fromLanguage, toLanguage);
  
  if (result) {
    return result;
  }

  return null;
}