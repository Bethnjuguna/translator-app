import { Card, CardContent } from "@/components/ui/card";
import { Volume2, Book, Heart } from "lucide-react";

export function FeatureCards() {
  return (
    <div className="mt-12 grid md:grid-cols-3 gap-6">
      <Card className="border-slate-200 text-center hover:shadow-lg transition-all duration-200">
        <CardContent className="p-6">
          <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Volume2 className="text-primary h-6 w-6" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-2">Pronunciation Guide</h3>
          <p className="text-slate-600 text-sm">Listen to native pronunciation for accurate speaking</p>
        </CardContent>
      </Card>
      
      <Card className="border-slate-200 text-center hover:shadow-lg transition-all duration-200">
        <CardContent className="p-6">
          <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Book className="text-secondary h-6 w-6" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-2">Cultural Context</h3>
          <p className="text-slate-600 text-sm">Learn when and how to use phrases appropriately</p>
        </CardContent>
      </Card>
      
      <Card className="border-slate-200 text-center hover:shadow-lg transition-all duration-200">
        <CardContent className="p-6">
          <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="text-accent h-6 w-6" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-2">Save Favorites</h3>
          <p className="text-slate-600 text-sm">Bookmark important phrases for quick access</p>
        </CardContent>
      </Card>
    </div>
  );
}
