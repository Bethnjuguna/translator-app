import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { History, ArrowRight, Heart } from "lucide-react";
import { getRecentTranslations } from "@/lib/storage";
import type { RecentTranslation } from "@shared/schema";

const languageFlags: Record<string, string> = {
  english: "🇺🇸",
  swahili: "🇰🇪",
  mandarin: "🇨🇳",
  hindi: "🇮🇳",
  arabic: "🇸🇦",
  spanish: "🇪🇸",
  russian: "🇷🇺",
  french: "🇫🇷",
  portuguese: "🇧🇷",
  japanese: "🇯🇵",
};

const languageNames: Record<string, string> = {
  english: "English",
  swahili: "Swahili",
  mandarin: "Mandarin",
  hindi: "Hindi",
  arabic: "Arabic",
  spanish: "Spanish",
  russian: "Russian",
  french: "French",
  portuguese: "Portuguese",
  japanese: "Japanese",
};

export function RecentTranslations() {
  const [recentTranslations, setRecentTranslations] = useState<RecentTranslation[]>([]);

  useEffect(() => {
    const loadRecentTranslations = () => {
      const recent = getRecentTranslations();
      setRecentTranslations(recent);
    };

    loadRecentTranslations();

    // Listen for storage changes to update the list
    const handleStorageChange = () => {
      loadRecentTranslations();
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Also update when localStorage is changed in the same tab
  useEffect(() => {
    const interval = setInterval(() => {
      const recent = getRecentTranslations();
      if (JSON.stringify(recent) !== JSON.stringify(recentTranslations)) {
        setRecentTranslations(recent);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [recentTranslations]);

  if (recentTranslations.length === 0) {
    return (
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">
          <History className="inline mr-3 h-6 w-6 text-secondary" />
          Recent Translations
        </h2>
        <Card className="border-slate-200">
          <CardContent className="text-center py-8">
            <p className="text-slate-500">No recent translations yet</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">
        <History className="inline mr-3 h-6 w-6 text-secondary" />
        Recent Translations
      </h2>
      <div className="grid gap-4">
        {recentTranslations.map((translation) => (
          <Card
            key={translation.id}
            className="border-slate-200 hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 text-sm text-slate-600 mb-2">
                    <span className="font-medium">
                      {languageFlags[translation.fromLanguage]} {languageNames[translation.fromLanguage]}
                    </span>
                    <ArrowRight className="h-3 w-3" />
                    <span className="font-medium">
                      {languageFlags[translation.toLanguage]} {languageNames[translation.toLanguage]}
                    </span>
                  </div>
                  <div className="font-medium text-slate-900">
                    {translation.fromText} → {translation.toText}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="p-2 text-slate-400 hover:text-accent-500 transition-colors duration-200"
                >
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
