import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Volume2, Heart, Copy, Info } from "lucide-react";
import type { TranslationResult } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { addFavoriteTranslation, isFavorite } from "@/lib/storage";
import { useState, useEffect } from "react";

interface ResultsSectionProps {
  result: TranslationResult | null;
  error: string | null;
  isVisible: boolean;
}

export function ResultsSection({ result, error, isVisible }: ResultsSectionProps) {
  const { toast } = useToast();
  const [isFav, setIsFav] = useState(false);

  useEffect(() => {
    if (result) {
      setIsFav(isFavorite(result.word, result.from.text, result.to.text));
    }
  }, [result]);

  const handlePlayAudio = () => {
    // For now, show a toast. In a real app, this would play TTS audio
    toast({
      title: "Audio Playback",
      description: "Audio pronunciation would play here in a real implementation.",
    });
  };

  const handleSaveToFavorites = () => {
    if (!result) return;

    if (!isFav) {
      addFavoriteTranslation({
        word: result.word,
        fromText: result.from.text,
        toText: result.to.text,
        fromLanguage: "english", // This would be dynamic based on the actual selection
        toLanguage: "spanish", // This would be dynamic based on the actual selection
      });
      setIsFav(true);
      toast({
        title: "Added to Favorites",
        description: "Translation saved to your favorites.",
      });
    } else {
      toast({
        title: "Already in Favorites",
        description: "This translation is already in your favorites.",
      });
    }
  };

  const handleCopyToClipboard = async () => {
    if (!result) return;

    try {
      await navigator.clipboard.writeText(result.to.text);
      toast({
        title: "Copied!",
        description: "Translation copied to clipboard.",
      });
    } catch {
      toast({
        title: "Copy Failed",
        description: "Unable to copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  if (!isVisible) return null;

  if (error) {
    return (
      <div className="mt-8 space-y-6 animate-in slide-in-from-bottom-4 duration-500">
        <Card className="shadow-lg border-slate-200">
          <CardContent className="text-center py-8">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-red-500 text-2xl">⚠️</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Translation Not Found</h3>
            <p className="text-slate-600">{error}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="mt-8 space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      {/* Translation Result */}
      <Card className="shadow-lg border-slate-200">
        <CardContent className="p-6 space-y-6">
          <div className="text-center">
            <div className="inline-flex items-center space-x-4 bg-slate-50 rounded-xl p-4">
              <div className="text-center">
                <div className="text-sm text-slate-600 mb-1">From</div>
                <div className="text-xl font-bold text-slate-900">{result.from.text}</div>
                <div className="text-sm text-slate-500">{result.from.pronunciation}</div>
              </div>
              <div className="text-2xl text-slate-400">
                <ArrowRight className="h-6 w-6" />
              </div>
              <div className="text-center">
                <div className="text-sm text-slate-600 mb-1">To</div>
                <div className="text-xl font-bold text-primary">{result.to.text}</div>
                <div className="text-sm text-slate-500">{result.to.pronunciation}</div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <Button
              onClick={handlePlayAudio}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 bg-primary-50 text-primary-700 border-primary-200 rounded-lg hover:bg-primary-100 transition-colors duration-200"
            >
              <Volume2 className="h-4 w-4" />
              <span>Listen</span>
            </Button>
            <Button
              onClick={handleSaveToFavorites}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 bg-secondary-50 text-secondary-700 border-secondary-200 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
            >
              <Heart className={`h-4 w-4 ${isFav ? 'fill-current' : ''}`} />
              <span>Save</span>
            </Button>
            <Button
              onClick={handleCopyToClipboard}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 bg-slate-50 text-slate-700 border-slate-200 rounded-lg hover:bg-slate-100 transition-colors duration-200"
            >
              <Copy className="h-4 w-4" />
              <span>Copy</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Cultural Context Card */}
      {result.culturalContext && (
        <Card className="bg-gradient-to-r from-accent-50 to-orange-50 border-accent-200 animate-in slide-in-from-bottom-4 duration-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-3">
              <Info className="inline mr-2 h-5 w-5 text-accent-500" />
              Cultural Context
            </h3>
            <div className="text-slate-700">
              <p>{result.culturalContext}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
