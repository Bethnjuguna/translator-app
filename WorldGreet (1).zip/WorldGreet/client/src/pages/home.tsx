import { useState } from "react";
import { TranslatorCard } from "@/components/translator-card";
import { ResultsSection } from "@/components/results-section";
import { RecentTranslations } from "@/components/recent-translations";
import { FeatureCards } from "@/components/feature-cards";
import { translateFromDictionary, getAvailableWords } from "@/lib/dictionary";
import { translateWithFallback } from "@/lib/external-translate";
import { addRecentTranslation } from "@/lib/storage";
import type { Language, TranslationResult } from "@shared/schema";
import { Globe } from "lucide-react";

export default function Home() {
  const [fromLanguage, setFromLanguage] = useState<Language>("english");
  const [toLanguage, setToLanguage] = useState<Language>("spanish");
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handleTranslate = async () => {
    if (!inputText.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    if (fromLanguage === toLanguage) {
      setError("Please select different source and target languages.");
      setIsLoading(false);
      setShowResults(true);
      return;
    }

    // First try our built-in dictionary
    console.log("Attempting translation:", inputText.trim(), "from", fromLanguage, "to", toLanguage);
    const dictionaryResult = translateFromDictionary(inputText.trim(), fromLanguage, toLanguage);
    console.log("Dictionary result:", dictionaryResult);

    if (dictionaryResult) {
      setResult(dictionaryResult);
      addRecentTranslation({
        word: dictionaryResult.word,
        fromText: dictionaryResult.from.text,
        toText: dictionaryResult.to.text,
        fromLanguage,
        toLanguage,
      });
      setIsLoading(false);
      setShowResults(true);
      return;
    }

    // If not found in dictionary, show helpful suggestions
    const availableWords = getAvailableWords();
    const suggestions = availableWords.slice(0, 5).join(', ');
    console.log("Available words:", availableWords.length, "words");
    setError(`"${inputText}" not found in our cultural dictionary. Try: ${suggestions}`);

    setIsLoading(false);
    setShowResults(true);
  };

  const handleSwapLanguages = () => {
    const temp = fromLanguage;
    setFromLanguage(toLanguage);
    setToLanguage(temp);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              <span className="text-4xl md:text-5xl">🌍</span> Culture Connect Translator
            </h1>
            <p className="text-slate-600 text-lg">Explore greetings and phrases across the globe</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Translator Card */}
        <TranslatorCard
          fromLanguage={fromLanguage}
          toLanguage={toLanguage}
          inputText={inputText}
          isLoading={isLoading}
          onFromLanguageChange={setFromLanguage}
          onToLanguageChange={setToLanguage}
          onInputChange={setInputText}
          onTranslate={handleTranslate}
          onSwapLanguages={handleSwapLanguages}
        />

        {/* Results Section */}
        <ResultsSection
          result={result}
          error={error}
          isVisible={showResults}
        />

        {/* Recent Translations */}
        <RecentTranslations />

        {/* Feature Cards */}
        <FeatureCards />
      </main>

      {/* Footer */}
      <footer className="mt-16 bg-slate-900 text-white py-8">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-slate-400">
            <Globe className="inline mr-2 h-4 w-4" />
            Connecting cultures, one word at a time
          </p>
        </div>
      </footer>
    </div>
  );
}
